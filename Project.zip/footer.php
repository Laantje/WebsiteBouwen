<!DOCTYPE HTML>

<!-- hiermee roepen we het stijlblad op -->
<link href="stijlblad1.css" rel="stylesheet" type="text/css"/>     

    <div id="footer">
        <div id="tekst">
         <br/>
                <a href="av.php">Algemene voorwaarden</a>
                <a href="contact.php">Contact</a>
         <br/>  <p> Copyright &copy; 2017 Wascessoires.nl </p>
        </div>
    </div>
</HTML>