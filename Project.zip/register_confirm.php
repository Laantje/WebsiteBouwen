<HTML>
	<HEAD>
		<TITLE>Wascessoires</TITLE>
		<style>
			.error {color: #FF0000;}
		</style>
    <?php
      include ('toolbar.php');
    ?>
	</HEAD>
	<BODY BGCOLOR="FFFFFF">
		<h1 align="center">Gelukt!</h1>
		<h2 align="center">Uw registratie is voltooid.</br><a href="index.php">Terug naar home</a></h2>
	</BODY>
  <FOOTER>
    <?php
      include ('toolbar.php');
    ?>
  </FOOTER>
</HTML>