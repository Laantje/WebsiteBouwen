<!DOCTYPE HTML>

e-mail: 
</br>nummer:

<form action="inlogpagina.php" method="post">
<input type="submit" value="inlogpagina">
</form>

</HTML>