<!DOCTYPE html>
<html>
    <title> Project </title>  
    <?php
    include('toolbar.php');
    ?>
    <link href="stijlblad2.css" rel="stylesheet" type="text/css"/>
  
    <!-- bij de content komt informatie over de site -->
    <div id="content"><center><h1>Welkom op de website Wascessoires!</h1></center>
        <div id="block1"><h2>Informatie</h2>
            <p>Wascessoires is opgericht in 2017 door 5 jongens die voor school een 
            project moesten maken. Het idee om een wasknijper webshop te maken heeft een tijdje geduurd. 
            We hebben verschillende plannen voor onze neus gehad, en zo hebben we uiteindelijk voor de meest originele gekozen.</p>
            <p>Over heel de wereld worden wasknijpers gebruikt. Iedereen heeft was dat gedroogd moet worden. 
                Dit gebeurt door de mens en waar mensen aan werken wordt er wel eens een foutje gemaakt.
                Het kan dus zo gebeuren dat er een keer een wasknijper verloren gaat of kapot gaat. 
                Al met al wasknijpers ben je altijd nodig en daarom leek het ons geschikt om hier een webshop van te maken.</p>             
            </div>
        <div id="block2"><center><h2>Contactinformatie</h2></center>
                <ul>
                    <li>Projectleider: Tjesse</li>
                    <li>Telefoonnummer: 06 - 12345678</li>
                    <li>Adres: Zernikeplein 11</li>
                </ul>
            </p>       
        </div>
        <div id="block2">
            <a href="register.php"><img src="meldjeaan.png"></a>
        </div>
</div>
<?php include('footer.php')?>
</div>