<!DOCTYPE HTML>

ALGEMENEVOORWAARDEN
<form action="inlogpagina.php" method="post">
<input type="submit" value="inlogpagina">
</form>

</HTML>